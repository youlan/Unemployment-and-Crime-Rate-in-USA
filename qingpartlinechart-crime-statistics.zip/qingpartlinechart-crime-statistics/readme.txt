Default: United States

Please change the id to the corresponding states to filter the data in the line chart.
(Currently didn't find the date of unemployment. So just show the crime rate now)