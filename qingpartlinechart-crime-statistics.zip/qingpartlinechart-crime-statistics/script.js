let lineChart = null;

d3.csv("data/crimerate.csv").then(crimeRate => {
  console.log(crimeRate);
  lineChart = new LineChart(crimeRate, "United States Total");
  //lineChart = new LineChart(crimeRate, "Utah");
  //lineChart = new LineChart(crimeRate, "Utah");
  //lineChart = new LineChart(crimeRate, "Wyoming");
});
