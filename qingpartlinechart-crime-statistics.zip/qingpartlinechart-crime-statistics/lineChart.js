class LineChart {
  constructor(data, id) {
    this.data = data;
    this.data.map(x => {
      x.Area = x.Area.trim();
    });
    this.margin = { top: 20, bottom: 60, left: 50, right: 20 };
    this.width = 500;
    this.height = 600;
    //! Fetch data
    this.id = id;
    this.year = this.data.map(d => d.Year);
    this.year = d3.set(this.year).values();
    this.crimeRate = this.data.filter(d => d.Area == id);

    this.crimeRate = this.crimeRate.map(d => d.rate);
    console.log(this.crimeRate);
    // Draw line chart
    this.update();
  }

  update() {
    let that = this;

    //add svg to div
    d3.select("#line-chart")
      .append("svg")
      .attr("id", "lineChart-svg");
    let svg = d3
      .select("#lineChart-svg")
      .attr("width", this.width)
      .attr("height", this.height)
      .attr("transform", "translate(900,100)");
    // draw axis
    let year = this.year;
    this.xScale = d3
      .scaleLinear()
      .domain([0, this.year.length - 1]) // input
      .range([0, this.width - this.margin.right - this.margin.left])
      .nice(); // output
    // (this.margin.right + this.margin.left)
    svg
      .append("g")
      .attr("class", "x axis")
      .attr(
        "transform",
        "translate(" +
          this.margin.left +
          "," +
          (this.height - this.margin.bottom) +
          ")"
      )
      .call(
        d3.axisBottom(this.xScale).tickFormat(function(d, i) {
          return year[i];
        })
      ); // Create an axis component with d3.axisBottom

    this.yScale = d3
      .scaleLinear()
      .domain([d3.min(this.crimeRate), d3.max(this.crimeRate)]) // input
      .range([this.height - this.margin.top - this.margin.bottom, 0])
      .nice(); // output

    svg
      .append("g")
      .attr("class", "y axis")
      .attr(
        "transform",
        "translate(" + this.margin.left + "," + this.margin.top + ")"
      )
      .call(d3.axisLeft(this.yScale));

    let dataset = d3.range(this.year.length).map((d, i) => {
      return { y: this.crimeRate[i] };
    });
    // Title
    svg
      .append("text")
      .attr(
        "transform",
        "translate(" +
          this.width / 2 +
          "," +
          (this.height - this.margin.bottom / 2 + 5) +
          ")"
      )
      .style("text-anchor", "middle")
      .text("Year");

    // text label for the y axis
    svg
      .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 0 - this.margin.left / 2 + 20)
      .attr("x", 0 - this.height / 2)
      .attr("dy", "1em")
      .style("text-anchor", "middle")
      .text("Crime Rate per 100,000");

    // Legend
    let legend = svg
      .append("g")
      .attr("class", "legend")
      .attr("transform", "translate(50,30)")
      .style("font-size", "14px");

    legend
      .append("rect")
      .attr("x", this.width - this.margin.right - this.margin.left)
      .attr("y", 9)
      .attr("width", 18)
      .attr("height", 18)
      .style("fill", "FF0000")
      .style("stroke", "#fff");

    legend
      .append("text")
      .attr("x", this.width - this.margin.right - this.margin.left - 10)
      .attr("y", 18)
      .attr("dy", ".35em")
      .style("text-anchor", "end")
      .text(this.id + " - Crime Rate");

    // draw lines
    let line = d3
      .line()
      .x((d, i) => {
        return this.xScale(i);
      }) // set the x values for the line generator
      .y(d => {
        return this.yScale(d.y);
      }) // set the y values for the line generator
      .curve(d3.curveMonotoneX); // apply smoothing to the line
    svg
      .append("path")
      .datum(dataset) // 10. Binds data to the line
      .attr("class", "line") // Assign a class for styling
      .attr(
        "transform",
        "translate(" + this.margin.left + "," + this.margin.top + ")"
      )
      .attr("d", line); // 11. Calls the line generator

    d3.select("#line-chart")
      .append("div")
      .classed("tooltip", true)
      .style("opacity", 0);

    let tooltip = d3.select(".tooltip");

    let circles = svg
      .selectAll(".dot")
      .data(dataset)
      .enter()
      .append("circle") // Uses the enter().append() method
      .attr("class", "dot") // Assign a class for styling
      .attr("cx", (d, i) => {
        return this.xScale(i);
      })
      .attr("cy", d => {
        return this.yScale(d.y);
      })
      .attr("r", 8)
      .attr(
        "transform",
        "translate(" + this.margin.left + "," + this.margin.top + ")"
      );
    //Add the tooltip labels on mouseover
    circles.on("mouseover", function(d, i) {
      //console.log(d);
      //show tooltip
      tooltip
        .transition()
        .duration(200)
        .style("opacity", 0.9);
      tooltip
        .html(that.tooltipRender(d, i) + "<br/>")
        .style("left", d3.event.pageX + 10 + "px")
        .style("top", d3.event.pageY + "px");
    });
    //hover function for country selection
    circles.on("mouseout", function(d) {
      tooltip
        .transition()
        .duration(500)
        .style("opacity", 0);
    });
  }
  tooltipRender(data, i) {
    let text = "<h2>" + "Year: " + this.year[i] + "</h2>";
    text += "<h2>" + "Crime Rate: " + data.y + "<h2>";
    return text;
  }
}
